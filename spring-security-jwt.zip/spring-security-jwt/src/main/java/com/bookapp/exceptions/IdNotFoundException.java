/**
 * 
 */
package com.bookapp.exceptions;

/**
 * @author BabaFakruddinDharuba
 *
 */
public class IdNotFoundException extends RuntimeException{

	/**
	 * 
	 */
	public IdNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param message
	 */
	public IdNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
